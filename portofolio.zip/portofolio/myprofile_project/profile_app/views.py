from django.shortcuts import render

def home(request):
    context = {
        'name': 'Abdu Basith Hilmy',
        'title': 'Mahasiswa',
        'email': 'abdulbasithhilmy12@gmail.com',
        'phone': '+62 852-1945-8753',
        'location': 'Bogor, Indonesia',
        'description': 'Halo! Saya mahasiswa Teknik Informatika tahun pertama di STT NF yang berada pada tahap awal pengembangan keahlian di bidang pemrograman. Saya memiliki minat dalam web development, khususnya pada dasar-dasar HTML dan CSS serta pemahaman awal terhadap logika pemrograman. Saat ini, saya aktif mempelajari dan mengerjakan proyek sederhana menggunakan Visual Studio Code serta mengenal penggunaan Git sebagai alat pengelolaan versi. Saya memiliki motivasi tinggi untuk terus belajar, meningkatkan kemampuan teknis, dan terbuka untuk bekerja sama dalam lingkungan pembelajaran maupun proyek pengembangan teknologi.',
        'social_links': {
        'github': 'https://github.com/basithhilmy12/YuaiYueks-12.git',
        }
    }
    return render(request, 'profile_app/home.html', context)

def about(request):
    context = {
        'education': [
            {
                'degree': 'SD',
                'institution': 'SDIT Daarul Fataa',
                'year': '2012 - 2018',
                'description': 'Dasar Pendidikan Islam Terpadu '
            },
            {
                'degree': 'SMP',
                'institution': 'SMP Negeri 1 Bojong Gede ( Belcram )',
                'year': '2018 - 2021',
                'description': 'Disiplin dan Kreatif'
            },
            {
                'degree': 'SMA ',
                'institution': 'SMA Negeri 1 Bojong Gede ( SMANBO )',
                'year': '2021 - 2024',
                'description': 'Mandiri dan Bertanggung Jawab'
            },
            {
                'degree': 'Mahasiswa Teknik Informatika',
                'institution': 'STT Nurul Fikri',
                'year': '2025 - Sekarang',
                'description': 'Pengembangan Diri'
            }
            
        ],
        'organizations': [
            {
                'role': 'Sekretaris',
                'organization': 'OSPQN',
                'period': '2022-2023',
                'description': 'Organisasi'
            },
            {
                'role': 'Kesehatan',
                'organization': 'OSPQN',
                'period': '2021-2022',
                'description': 'Organisasi'
            },
            {
                'role': 'MultiMedia',
                'organization': 'OSPQN',
                'period': '2021-2022',
                'description': 'Organisasi'
            }
        ]
    }
    return render(request, 'profile_app/about.html', context)

def gallery(request):
    context = {
        'gallery_items': [
            {
                'title': 'Discord Server',
                'description': 'Server Discord untuk Komunikasi Antar Anggota',
                'image': 'images/Discord.jpg',
                'date': '2025'
            },
            {
                'title': 'Lomba Futsal Asro 7,0',
                'description': 'Mengikuti Lomba Futsal di Asro 7,0',
                'image': 'images/Lomba.jpg',
                'date': '2025'
            },
            {
                'title': 'TI02 Laki-Laki',
                'description': 'Almet Man',
                'image': 'images/TI1A.jpg',
                'date': '2025'
            },
            {
                'title': 'Teknik Informatika 25',
                'description': 'Supporter TI25 di Gor Pasar Minggu',
                'image': 'images/TIPM.jpg',
                'date': '2025'
            }
        ]
    }
    return render(request, 'profile_app/gallery.html', context)