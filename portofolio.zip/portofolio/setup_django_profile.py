#!/usr/bin/env python3
"""
Script untuk membuat struktur lengkap Django Project - Profile Website
Jalankan dengan: python setup_django_profile.py
"""

import os
import sys

def create_file(path, content):
    """Helper function untuk membuat file dengan konten"""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✓ Created: {path}")

def main():
    print("🚀 Creating Django Profile Website Structure...\n")
    
    # Base directory
    base_dir = "myprofile_project"
    os.makedirs(base_dir, exist_ok=True)
    
    # ==================== DJANGO SETTINGS ====================
    settings_content = '''import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-your-secret-key-change-in-production'

DEBUG = True

ALLOWED_HOSTS = []

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'profile_app',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'myprofile.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'myprofile.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LANGUAGE_CODE = 'id-id'
TIME_ZONE = 'Asia/Jakarta'
USE_I18N = True
USE_TZ = True

STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
'''
    
    # ==================== URLS ====================
    main_urls_content = '''from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('profile_app.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
'''
    
    app_urls_content = '''from django.urls import path
from . import views

app_name = 'profile'

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('gallery/', views.gallery, name='gallery'),
]
'''
    
    # ==================== VIEWS ====================
    views_content = '''from django.shortcuts import render

def home(request):
    context = {
        'name': 'John Doe',
        'title': 'Full Stack Developer',
        'email': 'john.doe@example.com',
        'phone': '+62 812-3456-7890',
        'location': 'Jakarta, Indonesia',
        'description': 'Saya adalah seorang Full Stack Developer dengan pengalaman lebih dari 5 tahun dalam pengembangan aplikasi web modern. Passionate dalam menciptakan solusi digital yang inovatif dan user-friendly.',
        'skills': ['Python', 'Django', 'JavaScript', 'React', 'PostgreSQL', 'Docker'],
        'social_links': {
            'github': 'https://github.com/johndoe',
            'linkedin': 'https://linkedin.com/in/johndoe',
            'twitter': 'https://twitter.com/johndoe',
        }
    }
    return render(request, 'profile_app/home.html', context)

def about(request):
    context = {
        'education': [
            {
                'degree': 'S1 Teknik Informatika',
                'institution': 'Universitas Indonesia',
                'year': '2015 - 2019',
                'description': 'IPK: 3.75/4.00. Fokus pada Software Engineering dan Web Development.'
            },
            {
                'degree': 'SMA IPA',
                'institution': 'SMA Negeri 1 Jakarta',
                'year': '2012 - 2015',
                'description': 'Juara 1 Olimpiade Komputer tingkat Provinsi.'
            }
        ],
        'organizations': [
            {
                'role': 'Ketua Divisi IT',
                'organization': 'Himpunan Mahasiswa Informatika',
                'period': '2017 - 2018',
                'description': 'Memimpin tim dalam pengembangan sistem informasi kampus.'
            },
            {
                'role': 'Volunteer Developer',
                'organization': 'Tech for Good Indonesia',
                'period': '2019 - Sekarang',
                'description': 'Berkontribusi dalam proyek-proyek teknologi untuk sosial.'
            }
        ]
    }
    return render(request, 'profile_app/about.html', context)

def gallery(request):
    context = {
        'gallery_items': [
            {
                'title': 'Workshop Web Development',
                'description': 'Mengajar workshop Django untuk pemula di kampus',
                'image': 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800',
                'date': 'Januari 2024'
            },
            {
                'title': 'Hackathon Winner',
                'description': 'Juara 1 Hackathon Nasional dengan aplikasi Smart City',
                'image': 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800',
                'date': 'Maret 2024'
            },
            {
                'title': 'Tech Conference',
                'description': 'Pembicara di PyCon Indonesia 2024',
                'image': 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800',
                'date': 'Juni 2024'
            },
            {
                'title': 'Team Project',
                'description': 'Kolaborasi dengan tim dalam mengembangkan aplikasi e-commerce',
                'image': 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800',
                'date': 'Agustus 2024'
            }
        ]
    }
    return render(request, 'profile_app/gallery.html', context)
'''
    
    # ==================== BASE TEMPLATE ====================
    base_template = '''{% load static %}
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}My Profile{% endblock %}</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #6366f1;
            --secondary-color: #8b5cf6;
            --dark-color: #1e293b;
            --light-color: #f8fafc;
            --gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            color: var(--dark-color);
            overflow-x: hidden;
        }
        
        /* Navbar Modern */
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            padding: 1rem 0;
            transition: all 0.3s;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .nav-link {
            font-weight: 500;
            margin: 0 1rem;
            position: relative;
            transition: all 0.3s;
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 50%;
            background: var(--gradient);
            transition: all 0.3s;
            transform: translateX(-50%);
        }
        
        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }
        
        /* Hero Section */
        .hero-section {
            min-height: 100vh;
            background: var(--gradient);
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: moveBackground 20s linear infinite;
        }
        
        @keyframes moveBackground {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }
        
        /* Card Modern */
        .card-modern {
            border: none;
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.3s;
            background: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .card-modern:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        /* Buttons */
        .btn-gradient {
            background: var(--gradient);
            border: none;
            color: white;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.6);
            color: white;
        }
        
        /* Timeline */
        .timeline-item {
            position: relative;
            padding-left: 60px;
            padding-bottom: 40px;
        }
        
        .timeline-item::before {
            content: '';
            position: absolute;
            left: 20px;
            top: 0;
            bottom: -40px;
            width: 2px;
            background: linear-gradient(to bottom, var(--primary-color), var(--secondary-color));
        }
        
        .timeline-item:last-child::before {
            display: none;
        }
        
        .timeline-dot {
            position: absolute;
            left: 12px;
            top: 5px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: white;
            border: 3px solid var(--primary-color);
            box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.2);
        }
        
        /* Gallery */
        .gallery-item {
            position: relative;
            overflow: hidden;
            border-radius: 15px;
            cursor: pointer;
        }
        
        .gallery-item img {
            transition: all 0.5s;
            width: 100%;
            height: 300px;
            object-fit: cover;
        }
        
        .gallery-item:hover img {
            transform: scale(1.1);
        }
        
        .gallery-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(102, 126, 234, 0.9);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: all 0.3s;
            padding: 20px;
            text-align: center;
        }
        
        .gallery-item:hover .gallery-overlay {
            opacity: 1;
        }
        
        .gallery-overlay h4 {
            color: white;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .gallery-overlay p {
            color: rgba(255,255,255,0.9);
        }
        
        /* Footer */
        footer {
            background: var(--dark-color);
            color: white;
            padding: 40px 0 20px;
        }
        
        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
            color: white;
            margin: 0 5px;
            transition: all 0.3s;
        }
        
        .social-links a:hover {
            background: var(--primary-color);
            transform: translateY(-3px);
        }
        
        /* Skill Badge */
        .skill-badge {
            display: inline-block;
            padding: 8px 20px;
            background: rgba(99, 102, 241, 0.1);
            color: var(--primary-color);
            border-radius: 50px;
            font-size: 0.9rem;
            font-weight: 500;
            margin: 5px;
            transition: all 0.3s;
        }
        
        .skill-badge:hover {
            background: var(--primary-color);
            color: white;
            transform: translateY(-2px);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero-section {
                min-height: 80vh;
            }
            
            .navbar-brand {
                font-size: 1.2rem;
            }
        }
    </style>
    
    {% block extra_css %}{% endblock %}
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="{% url 'profile:home' %}">
                <i class="bi bi-code-slash"></i> MyProfile
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link {% if request.resolver_match.url_name == 'home' %}active{% endif %}" 
                           href="{% url 'profile:home' %}">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {% if request.resolver_match.url_name == 'about' %}active{% endif %}" 
                           href="{% url 'profile:about' %}">About Me</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {% if request.resolver_match.url_name == 'gallery' %}active{% endif %}" 
                           href="{% url 'profile:gallery' %}">Gallery</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Main Content -->
    {% block content %}{% endblock %}
    
    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    <p class="mb-0">&copy; 2024 MyProfile. Made with <i class="bi bi-heart-fill text-danger"></i> using Django & Bootstrap</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <div class="social-links">
                        <a href="#"><i class="bi bi-github"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- AOS Animation JS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 1000,
            once: true
        });
    </script>
    
    {% block extra_js %}{% endblock %}
</body>
</html>'''
    
    # ==================== HOME TEMPLATE ====================
    home_template = '''{% extends 'base.html' %}
{% block title %}Home - {{ name }}{% endblock %}

{% block content %}
<section class="hero-section d-flex align-items-center">
    <div class="container position-relative">
        <div class="row align-items-center">
            <div class="col-lg-6 text-white" data-aos="fade-right">
                <h1 class="display-3 fw-bold mb-4">Hi, I'm {{ name }}</h1>
                <h3 class="mb-4">{{ title }}</h3>
                <p class="lead mb-4">{{ description }}</p>
                
                <div class="mb-4">
                    {% for skill in skills %}
                    <span class="skill-badge bg-white text-primary">{{ skill }}</span>
                    {% endfor %}
                </div>
                
                <div class="d-flex gap-3 flex-wrap">
                    <a href="{% url 'profile:about' %}" class="btn btn-gradient btn-lg">
                        <i class="bi bi-person-circle me-2"></i>About Me
                    </a>
                    <a href="{% url 'profile:gallery' %}" class="btn btn-outline-light btn-lg">
                        <i class="bi bi-images me-2"></i>Gallery
                    </a>
                </div>
            </div>
            
            <div class="col-lg-6 text-center mt-5 mt-lg-0" data-aos="fade-left">
                <div class="position-relative">
                    <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500" 
                         alt="Profile" 
                         class="img-fluid rounded-circle shadow-lg"
                         style="width: 400px; height: 400px; object-fit: cover; border: 10px solid rgba(255,255,255,0.2);">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Info Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                <div class="card-modern text-center p-4">
                    <div class="mb-3">
                        <i class="bi bi-envelope-fill fs-1 text-primary"></i>
                    </div>
                    <h5 class="fw-bold">Email</h5>
                    <p class="text-muted mb-0">{{ email }}</p>
                </div>
            </div>
            
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                <div class="card-modern text-center p-4">
                    <div class="mb-3">
                        <i class="bi bi-telephone-fill fs-1 text-primary"></i>
                    </div>
                    <h5 class="fw-bold">Phone</h5>
                    <p class="text-muted mb-0">{{ phone }}</p>
                </div>
            </div>
            
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="300">
                <div class="card-modern text-center p-4">
                    <div class="mb-3">
                        <i class="bi bi-geo-alt-fill fs-1 text-primary"></i>
                    </div>
                    <h5 class="fw-bold">Location</h5>
                    <p class="text-muted mb-0">{{ location }}</p>
                </div>
            </div>
        </div>
    </div>
</section>
{% endblock %}'''
    
    # ==================== ABOUT TEMPLATE ====================
    about_template = '''{% extends 'base.html' %}
{% block title %}About Me{% endblock %}

{% block content %}
<!-- Page Header -->
<section class="py-5 mt-5" style="background: var(--gradient);">
    <div class="container text-center text-white py-5">
        <h1 class="display-4 fw-bold mb-3" data-aos="fade-up">About Me</h1>
        <p class="lead" data-aos="fade-up" data-aos-delay="100">Riwayat Pendidikan & Organisasi</p>
    </div>
</section>

<!-- Education Section -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-lg-8 text-center">
                <h2 class="fw-bold mb-3" data-aos="fade-up">
                    <i class="bi bi-mortarboard-fill text-primary me-2"></i>Pendidikan
                </h2>
                <p class="text-muted" data-aos="fade-up" data-aos-delay="100">
                    Perjalanan akademik yang membentuk fondasi pengetahuan saya
                </p>
            </div>
        </div>
        
        <div class="row justify-content-center">
            <div class="col-lg-10">
                {% for edu in education %}
                <div class="timeline-item" data-aos="fade-right" data-aos-delay="{{ forloop.counter|add:100 }}">
                    <div class="timeline-dot"></div>
                    <div class="card-modern p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h4 class="fw-bold mb-2">{{ edu.degree }}</h4>
                                <h5 class="text-primary mb-0">{{ edu.institution }}</h5>
                            </div>
                            <span class="badge bg-primary rounded-pill px-3 py-2">{{ edu.year }}</span>
                        </div>
                        <p class="text-muted mb-0">{{ edu.description }}</p>
                    </div>
                </div>
                {% endfor %}
            </div>
        </div>
    </div>
</section>

<!-- Organization Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-lg-8 text-center">
                <h2 class="fw-bold mb-3" data-aos="fade-up">
                    <i class="bi bi-people-fill text-primary me-2"></i>Organisasi
                </h2>
                <p class="text-muted" data-aos="fade-up" data-aos-delay="100">
                    Pengalaman berorganisasi dan kontribusi untuk masyarakat
                </p>
            </div>
        </div>
        
        <div class="row justify-content-center">
            <div class="col-lg-10">
                {% for org in organizations %}
                <div class="timeline-item" data-aos="fade-left" data-aos-delay="{{ forloop.counter|add:100 }}">
                    <div class="timeline-dot"></div>
                    <div class="card-modern p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h4 class="fw-bold mb-2">{{ org.role }}</h4>
                                <h5 class="text-primary mb-0">{{ org.organization }}</h5>
                            </div>
                            <span class="badge bg-success rounded-pill px-3 py-2">{{ org.period }}</span>
                        </div>
                        <p class="text-muted mb-0">{{ org.description }}</p>
                    </div>
                </div>
                {% endfor %}
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-5">
    <div class="container">
        <div class="card-modern p-5 text-center" style="background: var(--gradient);" data-aos="zoom-in">
            <h2 class="text-white fw-bold mb-3">Tertarik untuk Berkolaborasi?</h2>
            <p class="text-white mb-4">Mari kita ciptakan sesuatu yang luar biasa bersama!</p>
            <a href="{% url 'profile:home' %}" class="btn btn-light btn-lg">
                <i class="bi bi-chat-dots-fill me-2"></i>Hubungi Saya
            </a>
        </div>
    </div>
</section>
{% endblock %}'''
    
    # ==================== GALLERY TEMPLATE ====================
    gallery_template = '''{% extends 'base.html' %}
{% block title %}Gallery{% endblock %}

{% block content %}
<!-- Page Header -->
<section class="py-5 mt-5" style="background: var(--gradient);">
    <div class="container text-center text-white py-5">
        <h1 class="display-4 fw-bold mb-3" data-aos="fade-up">Gallery</h1>
        <p class="lead" data-aos="fade-up" data-aos-delay="100">Dokumentasi Kegiatan & Prestasi</p>
    </div>
</section>

<!-- Gallery Grid -->
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            {% for item in gallery_items %}
            <div class="col-md-6 col-lg-4" data-aos="zoom-in" data-aos-delay="{{ forloop.counter|add:100 }}">
                <div class="gallery-item shadow">
                    <img src="{{ item.image }}" alt="{{ item.title }}">
                    <div class="gallery-overlay">
                        <h4>{{ item.title }}</h4>
                        <p>{{ item.description }}</p>
                        <small class="text-white-50">
                            <i class="bi bi-calendar-event me-1"></i>{{ item.date }}
                        </small>
                    </div>
                </div>
            </div>
            {% endfor %}
        </div>
    </div>
</section>

<!-- Statistics Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-4 text-center">
            <div class="col-md-3 col-6" data-aos="fade-up">
                <div class="card-modern p-4">
                    <h2 class="display-4 fw-bold text-primary mb-2">50+</h2>
                    <p class="text-muted mb-0">Projects</p>
                </div>
            </div>
            <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="100">
                <div class="card-modern p-4">
                    <h2 class="display-4 fw-bold text-primary mb-2">100+</h2>
                    <p class="text-muted mb-0">Happy Clients</p>
                </div>
            </div>
            <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="200">
                <div class="card-modern p-4">
                    <h2 class="display-4 fw-bold text-primary mb-2">15+</h2>
                    <p class="text-muted mb-0">Awards</p>
                </div>
            </div>
            <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="300">
                <div class="card-modern p-4">
                    <h2 class="display-4 fw-bold text-primary mb-2">5+</h2>
                    <p class="text-muted mb-0">Years Experience</p>
                </div>
            </div>
        </div>
    </div>
</section>
{% endblock %}'''

    # ==================== APP FILES ====================
    app_init = "default_app_config = 'profile_app.apps.ProfileAppConfig'"
    
    app_models = '''from django.db import models

# Models dapat ditambahkan di sini jika diperlukan
'''
    
    app_admin = '''from django.contrib import admin

# Admin configuration dapat ditambahkan di sini
'''
    
    app_apps = '''from django.apps import AppConfig

class ProfileAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'profile_app'
'''
    
    # ==================== WSGI & ASGI ====================
    wsgi_content = '''import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myprofile.settings')
application = get_wsgi_application()
'''
    
    asgi_content = '''import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myprofile.settings')
application = get_asgi_application()
'''
    
    # ==================== MANAGE.PY ====================
    manage_py = '''#!/usr/bin/env python
import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myprofile.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed?"
        ) from exc
    execute_from_command_line(sys.argv)
'''
    
    # ==================== REQUIREMENTS ====================
    requirements = '''Django>=4.2,<5.0
Pillow>=10.0.0
'''
    
    # ==================== README ====================
    readme = '''# Django Profile Website

Website profile pribadi yang dibangun dengan Django dan Bootstrap 5.

## Fitur
- Homepage dengan informasi profile
- Halaman About dengan riwayat pendidikan & organisasi
- Gallery untuk dokumentasi kegiatan
- Responsive design (mobile-friendly)
- Modern UI dengan animasi

## Instalasi

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Jalankan migrasi:
```bash
python manage.py migrate
```

3. Buat superuser (opsional):
```bash
python manage.py createsuperuser
```

4. Jalankan development server:
```bash
python manage.py runserver
```

5. Buka browser di: http://127.0.0.1:8000/

## Struktur Project
```
myprofile_project/
├── myprofile/              # Project settings
├── profile_app/            # Main application
├── templates/              # HTML templates
├── static/                 # Static files (CSS, JS, images)
├── media/                  # User uploaded files
└── manage.py              # Django management script
```

## Kustomisasi

Edit file `profile_app/views.py` untuk mengubah:
- Data profile pribadi
- Riwayat pendidikan
- Pengalaman organisasi
- Gallery items

## Teknologi
- Django 4.2
- Bootstrap 5.3
- AOS Animation
- Bootstrap Icons
'''
    
    # ==================== CREATE ALL FILES ====================
    files_to_create = {
        # Project settings
        f"{base_dir}/myprofile/__init__.py": "",
        f"{base_dir}/myprofile/settings.py": settings_content,
        f"{base_dir}/myprofile/urls.py": main_urls_content,
        f"{base_dir}/myprofile/wsgi.py": wsgi_content,
        f"{base_dir}/myprofile/asgi.py": asgi_content,
        
        # App files
        f"{base_dir}/profile_app/__init__.py": app_init,
        f"{base_dir}/profile_app/models.py": app_models,
        f"{base_dir}/profile_app/views.py": views_content,
        f"{base_dir}/profile_app/urls.py": app_urls_content,
        f"{base_dir}/profile_app/admin.py": app_admin,
        f"{base_dir}/profile_app/apps.py": app_apps,
        f"{base_dir}/profile_app/tests.py": "from django.test import TestCase\n\n# Create your tests here.\n",
        
        # Templates
        f"{base_dir}/templates/base.html": base_template,
        f"{base_dir}/templates/profile_app/home.html": home_template,
        f"{base_dir}/templates/profile_app/about.html": about_template,
        f"{base_dir}/templates/profile_app/gallery.html": gallery_template,
        
        # Other files
        f"{base_dir}/manage.py": manage_py,
        f"{base_dir}/requirements.txt": requirements,
        f"{base_dir}/README.md": readme,
        f"{base_dir}/.gitignore": "*.pyc\n__pycache__/\ndb.sqlite3\n/media\n/staticfiles\n.env\n",
    }
    
    # Create directories
    directories = [
        f"{base_dir}/static/css",
        f"{base_dir}/static/js",
        f"{base_dir}/static/images",
        f"{base_dir}/media",
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✓ Created directory: {directory}")
    
    # Create all files
    for file_path, content in files_to_create.items():
        create_file(file_path, content)
    
    # Make manage.py executable
    if os.name != 'nt':  # Not Windows
        os.chmod(f"{base_dir}/manage.py", 0o755)
    
    print("\n" + "="*60)
    print("✅ Django Profile Project berhasil dibuat!")
    print("="*60)
    print(f"\n📁 Project location: {os.path.abspath(base_dir)}")
    print("\n🚀 Langkah selanjutnya:")
    print(f"   1. cd {base_dir}")
    print("   2. pip install -r requirements.txt")
    print("   3. python manage.py migrate")
    print("   4. python manage.py runserver")
    print("   5. Buka browser: http://127.0.0.1:8000/")
    print("\n💡 Tips:")
    print("   - Edit views.py untuk mengubah konten")
    print("   - Ganti gambar profile di home.html")
    print("   - Sesuaikan warna di CSS variables")
    print("\n" + "="*60)

if __name__ == "__main__":
    main()